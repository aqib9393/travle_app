package com.easyapproach.travelapp

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
